import ProductView from "@/components/ProductView";
import { notFound } from "next/navigation";
import { getProductBySlug } from "@/lib/an-sdk/products";

/* ================= METADATA ================= */
export async function generateMetadata({ params }) {
  try {
    const data = await getProductBySlug(params.slug);
    const p = data?.product;

    if (!p) {
      return { title: "Product Not Found" };
    }

    return {
      title: p?.name || "Product",
      description: p?.description || "",
      openGraph: {
        title: p?.name,
        description: p?.description,
        images: p?.images ? [p.images[0]] : [],
      },
    };
  } catch (err) {
    return {
      title: err?.status === 404 ? "Product Not Found" : "Server Error",
    };
  }
}

/* ================= PAGE ================= */
export default async function ProductPage({ params }) {
  const slug = params?.slug;

  if (!slug) return notFound();

  let data;

  try {
    data = await getProductBySlug(slug);
  } catch (err) {
    if (err?.status === 404) return notFound();

    return (
      <div style={{ padding: 40, textAlign: "center" }}>
        Server Error. Please try again later.
      </div>
    );
  }

  const product = data?.product;

  if (!product) return notFound();

  const variants = (data?.variants || []).map((v) => ({
    ...v,
    variant:
      v.variant || `${v.value || ""}${v.unit || ""}` || "Default",
    images: v.images?.length ? v.images : product.images || [],
  }));

  return <ProductView product={product} variants={variants} />;
}
