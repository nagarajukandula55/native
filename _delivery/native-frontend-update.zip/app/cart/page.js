"use client";

import Link from "next/link";
import { useCart } from "@/context/CartContext";
import RelatedProducts from "@/components/RelatedProducts";

export default function CartPage() {
  const { cart, updateQty, removeFromCart, cartTotal } = useCart();

  const crossSellSlug = cart.find((item) => item.slug)?.slug;

  return (
    <div className="container">
      <h1>Your Cart</h1>

      {cart.length === 0 ? (
        <div className="empty">
          <p>Cart is empty</p>
          <Link href="/products">
            <button className="browse">Browse Products</button>
          </Link>
        </div>
      ) : (
        <>
          {cart.map((item) => (
            <div key={item.productId} className="row">
              <img src={item.image || "/placeholder.png"} />

              <div>
                <h3>{item.name}</h3>
                <p>₹{item.price}</p>

                <div>
                  <button
                    onClick={() =>
                      updateQty(item.productId, item.qty - 1)
                    }
                  >
                    -
                  </button>

                  <span>{item.qty}</span>

                  <button
                    onClick={() =>
                      updateQty(item.productId, item.qty + 1)
                    }
                  >
                    +
                  </button>
                </div>

                <button
                  onClick={() =>
                    removeFromCart(item.productId)
                  }
                >
                  Remove
                </button>
              </div>
            </div>
          ))}

          <h2>Total: ₹{cartTotal}</h2>

          <Link href="/checkout">
            <button className="checkoutBtn">Proceed to Checkout →</button>
          </Link>
        </>
      )}

      <style jsx>{`
        .container {
          max-width: 900px;
          margin: auto;
          padding: 30px;
        }

        .empty {
          text-align: center;
          padding: 60px 0;
        }

        .browse {
          margin-top: 16px;
          padding: 12px 24px;
          border: none;
          border-radius: 30px;
          background: #c28b45;
          color: #fff;
          cursor: pointer;
        }

        .row {
          display: flex;
          gap: 20px;
          margin-bottom: 15px;
        }

        img {
          width: 100px;
          height: 100px;
          object-fit: cover;
        }

        .checkoutBtn {
          width: 100%;
          padding: 16px;
          margin-top: 10px;
          border: none;
          border-radius: 10px;
          background: #c28b45;
          color: #fff;
          font-size: 16px;
          cursor: pointer;
        }
      `}</style>

      {crossSellSlug && <RelatedProducts slug={crossSellSlug} />}
    </div>
  );
}
