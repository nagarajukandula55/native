"use client";

import {
  createContext,
  useContext,
  useEffect,
  useRef,
  useState,
} from "react";

/* =========================================================
   WISHLIST CONTEXT
   Mirrors CartContext's localStorage pattern so it works
   instantly for guests with zero backend dependency. Each
   entry keeps just enough product info to render a card
   without an extra fetch (id, slug, name, price, image).
========================================================= */

const WishlistContext = createContext<any>(null);

export function WishlistProvider({ children }: any) {
  const [wishlist, setWishlist] = useState<any[]>([]);
  const hydrated = useRef(false);

  /* LOAD */
  useEffect(() => {
    try {
      const saved = localStorage.getItem("wishlist");
      if (saved) setWishlist(JSON.parse(saved) || []);
    } catch (err) {
      console.error("Wishlist load failed:", err);
      setWishlist([]);
    }
    hydrated.current = true;
  }, []);

  /* SAVE */
  useEffect(() => {
    if (!hydrated.current) return;
    localStorage.setItem("wishlist", JSON.stringify(wishlist || []));
  }, [wishlist]);

  const isWishlisted = (productId: string) =>
    wishlist.some((p) => p.productId === productId);

  const addToWishlist = (product: any) => {
    if (!product) return;
    const productId = product.productId || product._id;
    if (!productId) return;

    setWishlist((prev) => {
      if (prev.some((p) => p.productId === productId)) return prev;
      return [
        ...prev,
        {
          productId,
          slug: product.slug || "",
          name: product.name || product.displayName || "Product",
          price: Number(
            product.price || product.displayPrice || product.minPrice || 0
          ),
          image: product.image || product.images?.[0] || "/placeholder.png",
          addedAt: Date.now(),
        },
      ];
    });
  };

  const removeFromWishlist = (productId: string) => {
    setWishlist((prev) => prev.filter((p) => p.productId !== productId));
  };

  const toggleWishlist = (product: any) => {
    const productId = product?.productId || product?._id;
    if (!productId) return;
    if (isWishlisted(productId)) removeFromWishlist(productId);
    else addToWishlist(product);
  };

  return (
    <WishlistContext.Provider
      value={{
        wishlist,
        wishlistCount: wishlist.length,
        isWishlisted,
        addToWishlist,
        removeFromWishlist,
        toggleWishlist,
      }}
    >
      {children}
    </WishlistContext.Provider>
  );
}

export const useWishlist = () => useContext(WishlistContext);
