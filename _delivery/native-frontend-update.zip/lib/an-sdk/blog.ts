import { anGet } from "./client";

export async function getBlogList() {
  return anGet("/api/blog/list");
}

export async function getBlogBySlug(slug: string) {
  return anGet(`/api/blog/${encodeURIComponent(slug)}`);
}
