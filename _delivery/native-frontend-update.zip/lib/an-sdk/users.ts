import { anGet, anPost } from "./client";

export async function adminListUsers() {
  return anGet("/api/admin/users");
}

export async function adminCreateUser(payload: any) {
  return anPost("/api/admin/users", payload);
}

export async function registerAdmin(payload: any) {
  return anPost("/api/admin/register", payload);
}
