import { anGet, anPost } from "./client";

export async function getCompany() {
  return anGet("/api/company");
}

export async function updateCompany(payload: any) {
  return anPost("/api/company", payload);
}
