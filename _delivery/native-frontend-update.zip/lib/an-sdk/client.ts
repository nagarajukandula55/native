/**
 * AN SDK — core HTTP client
 * ---------------------------------------------------------------
 * Every data call in this frontend goes through this file (directly,
 * or via one of the domain modules in lib/an-sdk/*). The backend for
 * all of these endpoints is owned by the AN group repo — this file
 * only needs NEXT_PUBLIC_AN_API to point at wherever that service is
 * deployed (see .env.example at the project root).
 *
 * Endpoint paths mirror the contract documented in the AN group's
 * backend-reference/API_CONTRACT.md bundle, so pointing this at a
 * compliant backend is a pure config change.
 */

const AN_API = process.env.NEXT_PUBLIC_AN_API || "";

const TOKEN_KEY = "an_token";

/* =========================================================
   TOKEN STORAGE (client-side session)
   The AN backend returns a bearer token on login/signup. We
   store it in localStorage and attach it to every request.
========================================================= */

export function getToken(): string | null {
  if (typeof window === "undefined") return null;
  try {
    return localStorage.getItem(TOKEN_KEY);
  } catch {
    return null;
  }
}

export function setToken(token: string | null) {
  if (typeof window === "undefined") return;
  try {
    if (token) localStorage.setItem(TOKEN_KEY, token);
    else localStorage.removeItem(TOKEN_KEY);
  } catch {
    /* ignore (private browsing, etc.) */
  }
}

export class ApiError extends Error {
  status: number;
  data: any;

  constructor(message: string, status: number, data?: any) {
    super(message);
    this.name = "ApiError";
    this.status = status;
    this.data = data;
  }
}

/* =========================================================
   CORE FETCH
   Accepts either a relative path ("/api/products") or an
   absolute URL. Always sends JSON, always attaches the bearer
   token when present, always parses JSON, always throws a
   typed ApiError on non-2xx so callers can just try/catch.
========================================================= */

export async function anFetch(endpoint: string, options: RequestInit = {}) {
  const url = endpoint.startsWith("http") ? endpoint : `${AN_API}${endpoint}`;

  const token = getToken();

  const headers: Record<string, string> = {
    "Content-Type": "application/json",
    ...(options.headers as Record<string, string> | undefined),
  };

  if (token && !headers.Authorization) {
    headers.Authorization = `Bearer ${token}`;
  }

  let res: Response;

  try {
    res = await fetch(url, {
      ...options,
      headers,
      cache: options.cache ?? "no-store",
    });
  } catch (err: any) {
    throw new ApiError(
      err?.message || "Network error — could not reach the API",
      0
    );
  }

  const contentType = res.headers.get("content-type") || "";
  const data = contentType.includes("application/json")
    ? await res.json().catch(() => ({}))
    : await res.text().catch(() => null);

  if (!res.ok) {
    const message =
      (data && typeof data === "object" && (data.message || data.error)) ||
      `Request failed (${res.status})`;
    throw new ApiError(message, res.status, data);
  }

  return data;
}

export const anGet = (endpoint: string, options?: RequestInit) =>
  anFetch(endpoint, { ...options, method: "GET" });

export const anPost = (endpoint: string, body?: any, options?: RequestInit) =>
  anFetch(endpoint, {
    ...options,
    method: "POST",
    body: body !== undefined ? JSON.stringify(body) : undefined,
  });

export const anPut = (endpoint: string, body?: any, options?: RequestInit) =>
  anFetch(endpoint, {
    ...options,
    method: "PUT",
    body: body !== undefined ? JSON.stringify(body) : undefined,
  });

export const anPatch = (endpoint: string, body?: any, options?: RequestInit) =>
  anFetch(endpoint, {
    ...options,
    method: "PATCH",
    body: body !== undefined ? JSON.stringify(body) : undefined,
  });

export const anDelete = (endpoint: string, body?: any, options?: RequestInit) =>
  anFetch(endpoint, {
    ...options,
    method: "DELETE",
    body: body !== undefined ? JSON.stringify(body) : undefined,
  });
