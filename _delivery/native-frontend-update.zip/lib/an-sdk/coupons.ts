import { anGet, anPost, anPatch, anDelete } from "./client";

export async function validateCoupon(code: string, subtotal: number) {
  return anPost("/api/coupons/validate", { code, subtotal });
}

export async function adminListCoupons() {
  return anGet("/api/coupons");
}

export async function adminCreateCoupon(payload: any) {
  return anPost("/api/coupons/create", payload);
}

export async function adminToggleCoupon(id: string, active: boolean) {
  return anPatch("/api/coupons/toggle", { id, active });
}

export async function adminDeleteCoupon(id: string) {
  return anDelete("/api/coupons/delete", { id });
}
