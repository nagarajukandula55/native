import { anGet, anPost, setToken, getToken } from "./client";

export async function login(identifier: string, password: string) {
  const data = await anPost("/api/auth/login", { identifier, password });
  if (data?.token) setToken(data.token);
  return data;
}

export async function signup(payload: {
  name: string;
  email: string;
  phone?: string;
  password: string;
}) {
  const data = await anPost("/api/auth/signup", payload);
  if (data?.token) setToken(data.token);
  return data;
}

export function logout() {
  setToken(null);
}

export function isLoggedIn() {
  return !!getToken();
}

/** Current session user. Returns null instead of throwing when logged out. */
export async function getMe() {
  if (!getToken()) return null;
  try {
    const data = await anGet("/api/auth/me");
    return data?.user || null;
  } catch {
    return null;
  }
}

export async function requestPasswordReset(email: string) {
  return anPost("/api/auth/reset-password/request", { email });
}

export async function confirmPasswordReset(payload: {
  token: string;
  password: string;
}) {
  return anPost("/api/auth/reset-password", payload);
}
