import { anGet, anPost } from "./client";

export async function createOrder(payload: any) {
  return anPost("/api/orders/create", payload);
}

export async function getOrder(orderId: string) {
  return anGet(`/api/orders/${orderId}`);
}

export async function getOrderById(orderId: string) {
  return anGet(`/api/orders/get-by-id?orderId=${encodeURIComponent(orderId)}`);
}

export async function getMyOrders() {
  return anGet("/api/orders/get");
}

export async function getTimeline(orderId: string) {
  return anGet(`/api/orders/timeline/${orderId}`);
}

export async function addOrderNote(orderId: string, note: string) {
  return anPost("/api/orders/add-note", { orderId, note });
}

export async function getOrders() {
  return anGet("/api/orders/list");
}

export async function adminGetOrders() {
  return anGet("/api/admin/orders");
}

export async function setOrderStatus(orderId: string, status: string) {
  return anPost("/api/orders/status", { orderId, status });
}

export async function updateOrderStatus(orderId: string, status: string) {
  return anPost("/api/orders/update-status", { orderId, status });
}

export async function adminUpdateOrderStatus(orderId: string, status: string) {
  return anPost("/api/admin/orders/update-status", { orderId, status });
}

export async function markOrderPaid(orderId: string) {
  return anPost("/api/orders/mark-paid", { orderId });
}
