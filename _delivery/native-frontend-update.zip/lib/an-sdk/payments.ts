import { anGet, anPost } from "./client";

export async function markPaid(orderId: string, utr?: string) {
  return anPost("/api/payment/mark-paid", { orderId, utr });
}

export async function verifyPayment(payload: {
  razorpay_order_id: string;
  razorpay_payment_id: string;
  razorpay_signature: string;
  orderId?: string;
}) {
  return anPost("/api/payment/verify", payload);
}

export async function getPaymentSettings() {
  return anGet("/api/admin/payment-settings");
}

export async function updatePaymentSettings(payload: any) {
  return anPost("/api/admin/payment-settings", payload);
}
