import { anGet, anPost } from "./client";

export async function loadShippingRates(orderId: string) {
  return anPost("/api/shipping/rates", { orderId });
}

export async function getCouriers(payload: any) {
  return anPost("/api/shipping/couriers", payload);
}

interface PackageData {
  weight: number;
  length: number;
  width: number;
  height: number;
}

export async function createShipment(
  orderId: string,
  dispatchType: string,
  courierId?: string,
  packageData: PackageData = { weight: 0.5, length: 10, width: 10, height: 10 }
) {
  return anPost("/api/shipping/create-shipment", {
    orderId,
    dispatchType,
    courierId,
    weight: packageData.weight,
    length: packageData.length,
    width: packageData.width,
    height: packageData.height,
  });
}

export async function cancelShipment(orderId: string) {
  return anPost("/api/shipping/cancel", { orderId });
}

export async function trackShipment(awb: string) {
  return anGet(`/api/shipping/track/${encodeURIComponent(awb)}`);
}

export async function generateLabel(orderId: string) {
  return anGet(`/api/shipping/generate-label/${orderId}`);
}

export async function requestPickup(orderId: string) {
  return anPost("/api/shipping/request-pickup", { orderId });
}
