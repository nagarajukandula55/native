import { anGet, anPost } from "./client";

export type Review = {
  id?: string;
  productId: string;
  rating: number;
  title?: string;
  body: string;
  authorName: string;
  verifiedPurchase?: boolean;
  createdAt?: string;
};

export async function getReviews(productId: string, page = 1) {
  return anGet(`/api/reviews?productId=${encodeURIComponent(productId)}&page=${page}`);
}

export async function getReviewSummary(productId: string) {
  return anGet(`/api/reviews/summary?productId=${encodeURIComponent(productId)}`);
}

export async function submitReview(review: Review) {
  return anPost("/api/reviews", review);
}
