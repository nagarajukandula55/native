import { anGet, anPost } from "./client";

export async function getServerWishlist(): Promise<string[]> {
  const data = await anGet("/api/wishlist");
  return data?.productIds || [];
}

export async function syncServerWishlist(productIds: string[]) {
  return anPost("/api/wishlist/sync", { productIds });
}
