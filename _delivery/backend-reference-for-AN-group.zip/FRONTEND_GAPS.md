# Frontend → Backend gaps found during the frontend rewiring

While disconnecting the frontend from the old Next.js backend and pointing it
at `lib/an-sdk/*` (which calls `${NEXT_PUBLIC_AN_API}<path>`), the following
mismatches were found between what the **frontend actually calls** and what
existed in the old `app/api/**` routes (documented in `API_CONTRACT.md`). The
frontend has been wired to call the paths below regardless — they will 404
until the AN group backend implements them (or an existing route is
repointed, where noted).

| Frontend calls | Old repo reality | What AN group should do |
|---|---|---|
| `GET /api/auth/me` | No route existed. `lib/useAuth.js` called `/api/user/me`, `context/UserContext.js` called `/api/user/profile` — two different, both non-existent, endpoints. | Add one canonical `GET /api/auth/me` returning `{ success, user: { id, name, email, phone, role, permissions } }` from the bearer token. Both frontend call sites now use this single endpoint. |
| `POST /api/auth/signup` | No route existed (only `/api/auth/login`). | Add signup, returning the same `{ success, token, user }` shape as login. |
| `POST /api/auth/reset-password/request` and `POST /api/auth/reset-password` | No route existed. | Add a two-step reset flow: request (send email/OTP) + confirm (token + new password). |
| `POST /api/warehouse/update` (old admin/warehouse page) | Real route is `/api/warehouse/update-status`. | Frontend now calls the real path via `warehouse.updateWarehouseStatus()` — no backend change needed, this was just a frontend bug. |
| `POST /api/shipping/request-pickup` | No route existed (closest: `create-shipment`, `cancel`). | Add a dedicated Shiprocket "schedule pickup" endpoint, or tell us to fold this into `create-shipment` and we'll drop the separate call. |
| `POST /api/admin/register` (admin/create page) | No route existed. | Either add this route, or confirm `POST /api/admin/users` should be used instead and we'll repoint the frontend. |
| `GET`/`POST /api/admin/categories` (super-admin/categories page) | No route existed anywhere — `Category`/`Subcategory` models exist but no CRUD route. | Add category/subcategory CRUD. Storefront also needs a public `GET /api/categories` (currently the storefront filter sidebar uses a hardcoded list — see below). |
| `GET /api/blog/list` (blog listing page) | No route existed — the old page queried Mongoose directly from a server component. | Add a simple published-posts list endpoint. |
| `GET`/`POST /api/inventory` (admin/inventory page) | No route existed — `Inventory` model + `lib/services/inventoryService.js` exist but were never exposed over HTTP. | Add basic stock read/adjust endpoints. |
| `POST /api/admin/products/update-inline` (products review queue quick-edit) | No route existed (closest: `/api/admin/products/update`). | Frontend now calls the existing `update` route via `adminUpdateProductInline()` — confirm the payload shape in API_CONTRACT.md matches what the review-queue quick-edit sends (id + partial fields). |
| `POST /api/ai-seo-multi` (bulk AI SEO generation on the products admin page) | No route existed (only single-item `ai-content`/`ai-compliance`). | Add a batch variant, or confirm the frontend should just call `ai-content` in a loop and we'll simplify. |

## New storefront features (not gaps in old behavior — net-new)

These are genuinely new endpoints for the features added during this
frontend refresh, already detailed in `API_CONTRACT.md` under "New endpoints
needed": product reviews/ratings (`/api/reviews*`), related products
(`/api/products/:slug/related`), wishlist sync (`/api/wishlist*`), and
extended search/filter/sort query params on `GET /api/products`.

| Frontend calls | Reality | What AN group should do |
|---|---|---|
| `POST /api/newsletter/subscribe` (footer signup, `lib/an-sdk/contact.ts`) | No route exists. | Add `{ email }` → subscribe to a mailing list (or forward to whatever ESP AN group already uses for other properties). Fails soft today — the form just shows an error toast if it 404s. |

Multi-vendor and SSO endpoints are tracked separately in
`MULTI_VENDOR_PROPOSAL.md` and `AUTH_AND_SSO.md` — not repeated here.

## Recommendation

None of the above block a first deploy — every gap fails soft in the
frontend (empty states, disabled buttons, or a caught error) rather than
crashing. Treat this list as the backlog for the AN group's first sprint,
roughly in the order listed (auth gaps first, since login/signup/reset are
on the critical path for every other feature).
