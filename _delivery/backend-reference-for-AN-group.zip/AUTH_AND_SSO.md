# Auth & SSO Contract

The frontend's auth layer (`lib/an-sdk/auth.ts` + `lib/an-sdk/sso.ts`) is
built to support two modes behind one env var
(`NEXT_PUBLIC_AUTH_MODE=direct|sso`), because the exact mechanism AN group
wants to use for shared login across its properties wasn't decided at the
time this was built. This file documents both so AN group can implement
whichever (or confirm one is already live).

## Mode 1 — `direct` (implemented today, default)

The frontend collects email/password itself and talks straight to:

- `POST /api/auth/login` — `{ identifier, password }` → `{ token, user }`
- `POST /api/auth/signup` — `{ name, email, phone?, password }` → `{ token, user }`
- `GET /api/auth/me` — bearer token → `{ user }` (frontend treats any
  non-2xx here as "not logged in", never an error)
- `POST /api/auth/reset-password/request` — `{ email }`
- `POST /api/auth/reset-password` — `{ token, password }`

Token is stored client-side (`localStorage`, key `an_token`) and sent as
`Authorization: Bearer <token>` on every subsequent call. This much
already exists in the original codebase (`API_CONTRACT.md`) — it's
carried over unchanged.

## Mode 2 — `sso` (proposed, not yet backed by a real endpoint)

When `NEXT_PUBLIC_AUTH_MODE=sso`, this frontend never shows its own
password form. Instead (`lib/an-sdk/sso.ts`):

1. User clicks "Continue with AN Account" → browser redirects to
   `NEXT_PUBLIC_AN_SSO_URL` (AN group's shared hosted login — the same
   one every other AN-group property points at) with
   `client_id`, `redirect_uri=<origin>/auth/callback`, `response_type=token`,
   and `state=<return path>`.
2. AN group authenticates the user and redirects back to
   `/auth/callback` with either:
   - `?token=...&state=...` (token issued directly), or
   - `?code=...&state=...` (auth code this frontend exchanges via
     `POST /api/auth/sso/exchange` — **new endpoint, does not exist yet**
     — `{ code }` → `{ token, user }`)
3. Frontend stores the token exactly like mode 1 from that point on —
   every other SDK module, every page, is unaware which mode produced it.

### What AN group needs to confirm/provide for mode 2

- The real value for `NEXT_PUBLIC_AN_SSO_URL` (currently empty/unset —
  the live API base URL and SSO URL weren't available yet when this was
  built).
- Whether the redirect carries a token directly or an auth code (both are
  handled by `completeSsoCallback()`; whichever AN group's other
  properties already use is fine — the frontend adapts, no rework needed).
- If a code, the `POST /api/auth/sso/exchange` endpoint itself.
- Whether `role` (customer / vendor / admin / super-admin) comes back in
  the user object from this same flow, since the whole app — including
  the vendor dashboard and admin areas — gates on `user.role`.

## Nothing in this repo hardcodes a specific SSO provider

No OAuth/OIDC/SAML library, client SDK, or provider-specific redirect
shape is wired in — intentionally, since the mechanism wasn't decided.
Swapping mode 2's implementation only ever touches `lib/an-sdk/sso.ts` and
`app/auth/callback/page.js`; nothing else in the app imports either
directly except the login page.
