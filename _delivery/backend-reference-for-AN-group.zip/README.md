# Backend Reference Bundle — for the AN Group Repo

This is **not a runnable frontend** — it's the extracted backend half of the
`native` e-commerce codebase, handed off so the AN group can stand up a
standalone backend service that the frontend (now a pure Next.js frontend
elsewhere) calls over HTTP.

## Start here

1. **`API_CONTRACT.md`** — the full endpoint-by-endpoint spec: every route
   that exists in this bundle today, its auth requirements (spoiler: almost
   none currently have any), request/response shape, side effects, and
   which external services it depends on (Razorpay, Shiprocket, GST
   verification, Cloudinary, email/WhatsApp/Telegram). Also includes a
   "Data models" section summarizing every Mongoose schema. Read this
   first — in particular its "Overview / things worth fixing" section,
   which flags that `POST /api/payment/verify` never actually checks the
   Razorpay signature and unconditionally marks orders paid, combined with
   zero auth enforcement anywhere in the bundle.
2. **`FRONTEND_GAPS.md`** — a shorter, prioritized punch list of endpoints
   the frontend calls that have no matching route in the code below at all
   (auth signup/reset-password, categories CRUD, blog list, inventory, a
   couple of frontend bugs that called the wrong path). Treat this as
   sprint-one backlog, ordered roughly by how many other features depend on
   it (auth first).
3. **`MULTI_VENDOR_PROPOSAL.md`** — the proposed data model and endpoint
   contract for turning Native into one tenant/business inside a
   multi-vendor marketplace (vendor onboarding, vendor dashboards, public
   vendor storefronts, admin vendor management, and Native's own business
   registration with AN group). None of these endpoints exist yet — this is
   a starting proposal to reconcile with AN group's existing
   vendor-onboarding process.
4. **`AUTH_AND_SSO.md`** — the two-mode auth contract the frontend expects
   (`direct` today; a proposed `sso` mode for the shared AN-group login
   used across other properties). Documents exactly what AN group needs to
   confirm/provide to turn mode 2 on.
5. **The frontend's `mock-backend/` folder** (not in this bundle — it lives
   in the frontend repo) is a working, dependency-free implementation of
   this entire contract with in-memory fake data, plus a smoke test
   (`npm run smoke-test`) that hits every endpoint and checks the response
   shape. **Point that same smoke test at your staging backend** as you
   build it — `AN_API=https://staging.angroup... node mock-backend/smoke-test.js`
   — and it'll tell you immediately which endpoints don't match what the
   frontend expects, endpoint by endpoint, instead of finding out from a
   broken screen later.

## What's in here

- **`app/api/`** — every original Next.js API route handler (Mongoose
  queries, Razorpay/Shiprocket/GST/email calls, business rules, response
  shapes). This is the reference implementation — port the logic, the
  routes don't need to stay in Next.js API-route form.
- **`models/`** — every Mongoose schema (Product, Order, User, Coupon,
  Inventory, Warehouse, CompanySettings, etc.).
- **`lib/`** — the business-logic modules the routes call into: order state
  machine (`engine/`, `service/`, `safe/createOrderSafe.js`), invoice/receipt
  generation (`invoice/`, `receipt/`, `pdf/`, `erp/`), GST (`gst.js`,
  `hsn.js`), Shiprocket integration (`shiprocket.js`), notifications
  (`email.js`, `whatsapp.js`, `telegram.js`), auth/permissions (`auth.js`,
  `guard.js`, `permissions.js`), and more.
- **`layouts/`** — the JSON layout definitions the invoice/receipt PDF
  renderer reads (`invoice/b2b.json`, `invoice/b2c.json`, `note/credit.json`,
  `note/debit.json`).
- **`scripts/import-pincodes.ts`** — the pincode data import script (pairs
  with the `Pincode` model and the pincode-lookup endpoint). You'll also need
  the original `pincodes.csv` data file, which was too large to include here
  — pull it from the original repo's `data/pincodes.csv` or root
  `pincodes.csv`.

## Things worth fixing while you're rebuilding, not just porting as-is

`API_CONTRACT.md`'s overview section flags these in detail, but in short:
no route currently enforces the auth/permission checks that `guard.js` and
`permissions.js` were clearly designed for; there are 3-4 duplicate/divergent
implementations of order-status transitions and invoice numbering that
should collapse into one; Razorpay payment verification doesn't actually
check the signature; and response shapes are inconsistent across routes
(some wrap in `{success, data}`, some return bare arrays/objects) — worth
standardizing before the frontend integrates against it for real.
