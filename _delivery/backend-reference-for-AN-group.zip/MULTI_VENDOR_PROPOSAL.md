# Multi-Vendor Marketplace Proposal

Native's frontend has been extended to work as one **tenant/business**
inside a shared, multi-vendor AN group marketplace, with its own vendors
selling products under it. None of the routes below exist in the original
single-seller codebase (`API_CONTRACT.md` documents that one) — this file
is the proposed contract for the new layer, called from
`lib/an-sdk/vendors.ts` on the frontend. Per the AN group team's own
note, vendor **onboarding as a process already exists on the AN group
side** — what's new here is (a) registering Native itself as a business
under that process, and (b) the endpoint shapes this frontend expects for
vendors that get onboarded underneath it. Treat this as a starting
proposal to reconcile with whatever AN group's existing vendor-onboarding
service already does, not a from-scratch spec.

## Two registration levels — don't conflate them

1. **Business registration** (one-time, admin-only): Native registers
   itself as a business/tenant on the shared AN group platform, the same
   way any other AN group storefront would. `GET /api/business/status`
   and `POST /api/business/register` in `lib/an-sdk/vendors.ts` cover this.
2. **Vendor onboarding** (ongoing, self-serve): individual sellers apply
   to sell *on Native specifically* (`POST /api/vendors/apply`), get
   reviewed by a Native admin, and once approved manage their own
   products/orders/payouts scoped to Native. This is the bulk of the
   endpoints below.

## Suggested data model additions

- **Vendor**: `_id, businessName, contactName, email, phone, gstNumber,
  category, status (pending|active|suspended|rejected), slug, logo,
  description, createdAt, approvedAt, approvedBy`
- **Product**: add `vendorId` (nullable — null/absent means "sold directly
  by Native", preserving today's single-seller behavior for existing
  products)
- **Order**: either split into per-vendor sub-orders at checkout time, or
  keep one Order with per-line-item `vendorId` and derive vendor-scoped
  views by filtering — either works with the endpoints below, but pick one
  and document it since it changes how payouts get calculated
- **Payout**: `_id, vendorId, orderIds[], amount, status
  (pending|processing|paid), paidAt`

## Endpoints this frontend now calls

All of these are new proposals; none existed before.

### Vendor onboarding & self-service (`lib/an-sdk/vendors.ts`)

| Method | Path | Auth | Purpose |
|---|---|---|---|
| POST | `/api/vendors/apply` | logged-in user | Submit a "Sell on Native" application |
| GET | `/api/vendors/me/status` | logged-in user | Check the current user's own application/vendor status |
| GET | `/api/vendors/me` | vendor | Own vendor profile |
| PUT | `/api/vendors/me` | vendor | Update own profile (name, logo, description, etc.) |
| GET | `/api/vendors/me/stats` | vendor | Dashboard summary (orders, revenue, pending payouts) |
| GET | `/api/vendors/me/products` | vendor | List own products |
| POST | `/api/vendors/me/products` | vendor | Create a product under this vendor |
| PUT | `/api/vendors/me/products/:id` | vendor | Update own product |
| DELETE | `/api/vendors/me/products/:id` | vendor | Remove own product |
| GET | `/api/vendors/me/orders` | vendor | Orders (or order line items) containing this vendor's products |
| POST | `/api/vendors/me/orders/:orderId/status` | vendor | Update fulfillment status for the vendor's portion of an order |
| GET | `/api/vendors/me/payouts` | vendor | Payout history/balance |

### Public storefronts

| Method | Path | Auth | Purpose |
|---|---|---|---|
| GET | `/api/vendors` | public | List active vendors (for a directory page) |
| GET | `/api/vendors/:idOrSlug` | public | Public vendor profile (name, logo, description, rating) |
| GET | `/api/vendors/:idOrSlug/products` | public | Products sold by this vendor, for `app/vendors/[id]/page.js` |

Existing product responses should also grow a `vendor` field
(`{ id, name, slug }` or null) so `ProductCard`/`ProductView` can render
"Sold by X" and link to the vendor's storefront without a second request.

### Admin vendor management

| Method | Path | Auth | Purpose |
|---|---|---|---|
| GET | `/api/admin/vendors` | admin | List vendors, filterable by status |
| GET | `/api/admin/vendors/:id` | admin | Full vendor detail for the review screen |
| POST | `/api/admin/vendors/:id/approve` | admin | Approve a pending application |
| POST | `/api/admin/vendors/:id/reject` | admin | Reject with a reason |
| POST | `/api/admin/vendors/:id/suspend` | admin | Suspend an active vendor |
| POST | `/api/admin/vendors/:id/reinstate` | admin | Un-suspend |

### Business (tenant) registration

| Method | Path | Auth | Purpose |
|---|---|---|---|
| GET | `/api/business/status` | admin | Is Native registered as a business with AN group yet, and what's the status |
| POST | `/api/business/register` | admin | Register Native as a business (name, legal name, GST, contact) |
| PUT | `/api/business/settings` | admin | Update Native's business-level settings once registered |

## Open questions for AN group

- Does AN group's existing vendor-onboarding flow issue its own
  vendor-facing login, or do vendors authenticate through the same SSO
  as customers/admins (see `AUTH_AND_SSO.md`) and get a `role: "vendor"`
  claim? The frontend assumes the latter (one login, role-gated UI).
- Split orders per vendor at checkout, or one order with per-line-item
  vendor attribution? Changes payout accounting and what
  `GET /api/vendors/me/orders` actually returns.
- Where does payout money movement happen — is that inside this API
  surface at all, or purely an AN group back-office concern this frontend
  never needs to call into beyond reading payout history?
